# Car Evaluation Dataset (Classification)

In this project, I have done exploratory data analysis of the 'Car Evaluation Data'. Pleases read data description file to get the details of dataset.

Further I have trained classification model for this dataset.

I do not believe in just applying functions to dataset. I have trained various models for the dataset starting from basic ones to advanced models. I have also explained parameter selection, feature selection,etc. based on results and graphs of trained models.

I have included Jupyter Notebook of this project which conatins codes, graphs,etc. I have also included .html file of notebook if you wish to have a quick glance of project.
