# Car Evaluation Data Set

The Car Evaluation Dataset is donated by Marko Bohanec and Blaz Zupan and is downloaded from [UCI Repository](https://archive.ics.uci.edu/ml/datasets/Car+Evaluation).

The car dataset has 6 attributes and 1728 instances. Using the data we predict the output value i.e. how good is the car.
